#ifndef __LIBRARY_ALL_HPP__
#define __LIBRARY_ALL_HPP__

//@ with first letter upper case, the file declares a class
//@ with firtt letter lower case, the file declare a function

#include "getSafeRect.cpp"//@a function
#include "getAttitude.cpp"//@a function

#endif

